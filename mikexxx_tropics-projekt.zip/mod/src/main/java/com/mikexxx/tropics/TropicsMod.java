package com.mikexxx.tropics;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

@Mod(TropicsMod.MODID)
public class TropicsMod {
    public static final String MODID = "mikexxx_tropics";
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    private static final String[] NAMES = {"giant_hibiscus","giant_heliconia","giant_bird_of_paradise","giant_frangipani","giant_king_protea"};
    private static final int[] HEIGHTS = {4,5,5,3,3};
    public static final List<RegistryObject<Item>> PLANT_ITEMS = new ArrayList<>();

    static {
        for (int i = 0; i < NAMES.length; i++) {
            final int h = HEIGHTS[i];
            final RegistryObject<Block> block = BLOCKS.register(NAMES[i], () -> new GiantPlantBlock(h));
            PLANT_ITEMS.add(ITEMS.register(NAMES[i], () -> new BlockItem(block.get(), new Item.Properties())));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("tropics", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup." + MODID))
            .icon(() -> new ItemStack(PLANT_ITEMS.get(0).get()))
            .displayItems((params, output) -> {
                for (RegistryObject<Item> item : PLANT_ITEMS) {
                    output.accept(item.get());
                }
            })
            .build());

    public TropicsMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
